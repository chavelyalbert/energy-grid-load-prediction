European Grid Stress Prediction - ML Pipeline v2
Author: Peter Leme
Created: 2025-11-26 09:15:55

MODELS:
- Regression (Random Forest): Test R2 = 0.8749
- Classification (Random Forest): Test F1 = 0.8932

DATA:
- Total: 551,794 samples
- Features: 28
- Countries: 23

FILES:
1. grid_stress_preprocessing.pkl
2. grid_stress_regression_model.pkl
3. grid_stress_classification_model.pkl
4. regression_results_all.pkl
5. classification_results_all.pkl
6. model_metadata.pkl
7. model_metadata.json
8. README.txt
